"""PubMed Paper Fetcher for Pharmaceutical Research."""

__version__ = "0.1.0"
