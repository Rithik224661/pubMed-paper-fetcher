"""Module for interacting with the PubMed API."""

import logging
from typing import Dict, List, Optional, Union

from Bio import Entrez

# Configure logging
logger = logging.getLogger(__name__)


class PubMedClient:
    """Client for interacting with the PubMed API."""

    def __init__(self, email: str, api_key: Optional[str] = None) -> None:
        """
        Initialize the PubMed client.

        Args:
            email: Email address to identify yourself to NCBI
            api_key: Optional NCBI API key for higher rate limits
        """
        self.email = email
        self.api_key = api_key
        Entrez.email = email
        if api_key:
            Entrez.api_key = api_key

    def search(self, query: str, max_results: int = 100) -> List[str]:
        """
        Search PubMed for articles matching the query.

        Args:
            query: PubMed search query
            max_results: Maximum number of results to return

        Returns:
            List of PubMed IDs matching the query
        """
        logger.info(f"Searching PubMed for: {query}")
        try:
            handle = Entrez.esearch(
                db="pubmed", term=query, retmax=max_results, sort="relevance"
            )
            record = Entrez.read(handle)
            handle.close()

            pmids = record["IdList"]
            logger.info(f"Found {len(pmids)} results")
            return pmids
        except Exception as e:
            logger.error(f"Error searching PubMed: {e}")
            raise

    def fetch_details(self, pmids: List[str]) -> Dict:
        """
        Fetch detailed information for a list of PubMed IDs.

        Args:
            pmids: List of PubMed IDs

        Returns:
            Dictionary containing detailed information for each article
        """
        logger.info(f"Fetching details for {len(pmids)} articles")
        try:
            handle = Entrez.efetch(db="pubmed", id=",".join(pmids), retmode="xml")
            records = Entrez.read(handle)
            handle.close()
            return records
        except Exception as e:
            logger.error(f"Error fetching article details: {e}")
            raise

    def fetch_article_details(self, pmid: str) -> Dict:
        """
        Fetch detailed information for a single PubMed ID.

        Args:
            pmid: PubMed ID

        Returns:
            Dictionary containing detailed information for the article
        """
        return self.fetch_details([pmid])
