"""Module for parsing PubMed API results."""

import logging
import re
from datetime import datetime
from typing import Dict, List, Optional, Tuple

# Configure logging
logger = logging.getLogger(__name__)


class PubMedParser:
    """Parser for PubMed API results."""

    def parse_articles(self, records: Dict) -> List[Dict]:
        """
        Parse PubMed records into a list of article dictionaries.

        Args:
            records: PubMed records from efetch

        Returns:
            List of dictionaries containing article information
        """
        articles = []

        for article in records["PubmedArticle"]:
            try:
                article_info = self._extract_article_info(article)
                if article_info:
                    articles.append(article_info)
            except Exception as e:
                pmid = article.get("MedlineCitation", {}).get("PMID", "Unknown")
                logger.error(f"Error parsing article {pmid}: {e}")
                continue

        return articles

    def _extract_article_info(self, article: Dict) -> Optional[Dict]:
        """
        Extract relevant information from a PubMed article.

        Args:
            article: PubMed article record

        Returns:
            Dictionary containing extracted article information
        """
        try:
            medline_citation = article.get("MedlineCitation", {})
            article_data = medline_citation.get("Article", {})

            # Extract basic article information
            pmid = medline_citation.get("PMID", "")
            title = article_data.get("ArticleTitle", "")

            # Extract publication date
            pub_date = self._extract_publication_date(article_data)

            # Extract authors and their affiliations
            (
                authors,
                non_academic_authors,
                company_affiliations,
                corresponding_email,
            ) = self._extract_author_info(article_data)

            # Only include articles with at least one non-academic author
            if not non_academic_authors:
                return None

            return {
                "pmid": pmid,
                "title": title,
                "publication_date": pub_date,
                "authors": authors,
                "non_academic_authors": non_academic_authors,
                "company_affiliations": company_affiliations,
                "corresponding_email": corresponding_email,
            }
        except Exception as e:
            logger.error(f"Error extracting article info: {e}")
            return None

    def _extract_publication_date(self, article_data: Dict) -> str:
        """
        Extract publication date from article data.

        Args:
            article_data: Article data from PubMed

        Returns:
            Publication date as a string (YYYY-MM-DD)
        """
        try:
            pub_date_info = (
                article_data.get("Journal", {})
                .get("JournalIssue", {})
                .get("PubDate", {})
            )

            # Try to get year, month, day
            year = pub_date_info.get("Year", "")
            month = pub_date_info.get("Month", "1")
            day = pub_date_info.get("Day", "1")

            # Convert month name to number if needed
            if month.isalpha():
                try:
                    month = str(datetime.strptime(month, "%b").month)
                except ValueError:
                    try:
                        month = str(datetime.strptime(month, "%B").month)
                    except ValueError:
                        month = "1"

            # Format date
            if year:
                return f"{year}-{month.zfill(2)}-{day.zfill(2)}"
            return ""
        except Exception as e:
            logger.error(f"Error extracting publication date: {e}")
            return ""

    def _extract_author_info(
        self, article_data: Dict
    ) -> Tuple[List[str], List[str], List[str], str]:
        """
        Extract author information from article data.

        Args:
            article_data: Article data from PubMed

        Returns:
            Tuple containing:
            - List of all author names
            - List of non-academic author names
            - List of company affiliations
            - Corresponding author email
        """
        authors = []
        non_academic_authors = []
        company_affiliations = []
        corresponding_email = ""

        author_list = article_data.get("AuthorList", [])

        if not author_list:
            return [], [], [], ""

        for author in author_list:
            # Skip if not a valid author
            if not isinstance(author, dict):
                continue

            # Extract author name
            last_name = author.get("LastName", "")
            fore_name = author.get("ForeName", "")
            initials = author.get("Initials", "")

            if last_name:
                if fore_name:
                    author_name = f"{last_name} {fore_name}"
                elif initials:
                    author_name = f"{last_name} {initials}"
                else:
                    author_name = last_name
                authors.append(author_name)
            else:
                continue

            # Extract affiliations
            affiliations = []
            if "AffiliationInfo" in author:
                for affiliation in author["AffiliationInfo"]:
                    if "Affiliation" in affiliation:
                        affiliations.append(affiliation["Affiliation"])

            # Check for corresponding author email
            if not corresponding_email:
                email_match = None
                for affiliation in affiliations:
                    email_match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", affiliation)
                    if email_match:
                        corresponding_email = email_match.group(0)
                        break

            # Check if author is from a non-academic institution
            is_non_academic = False
            for affiliation in affiliations:
                if self._is_company_affiliation(affiliation):
                    is_non_academic = True
                    company_name = self._extract_company_name(affiliation)
                    if company_name and company_name not in company_affiliations:
                        company_affiliations.append(company_name)

            if is_non_academic:
                non_academic_authors.append(author_name)

        return authors, non_academic_authors, company_affiliations, corresponding_email

    def _is_company_affiliation(self, affiliation: str) -> bool:
        """
        Determine if an affiliation is from a pharmaceutical or biotech company.

        Args:
            affiliation: Affiliation string

        Returns:
            True if the affiliation is from a company, False otherwise
        """
        # Convert to lowercase for case-insensitive matching
        affiliation_lower = affiliation.lower()

        # Keywords that suggest academic institutions (negative indicators)
        academic_keywords = [
            "university",
            "college",
            "institute",
            "school",
            "hospital",
            "medical center",
            "clinic",
            "foundation",
            "academy",
            "national",
            "federal",
            "ministry",
            "department of health",
        ]

        # Keywords that suggest pharmaceutical/biotech companies (positive indicators)
        company_keywords = [
            "pharma",
            "pharmaceuticals",
            "biotech",
            "therapeutics",
            "inc.",
            "inc",
            "llc",
            "ltd",
            "limited",
            "corp",
            "corporation",
            "biosciences",
            "laboratories",
            "labs",
            "gmbh",
            "co.",
            "ag",
            "biopharma",
            "medicines",
            "drugs",
            "health products",
        ]

        # Check for company indicators
        has_company_indicator = any(
            keyword in affiliation_lower for keyword in company_keywords
        )

        # Check for academic indicators
        has_academic_indicator = any(
            keyword in affiliation_lower for keyword in academic_keywords
        )

        # If it has company indicators and no academic indicators, consider it a company
        return has_company_indicator and not has_academic_indicator

    def _extract_company_name(self, affiliation: str) -> str:
        """
        Extract company name from affiliation string.

        Args:
            affiliation: Affiliation string

        Returns:
            Extracted company name or empty string if not found
        """
        # Common patterns for company names
        patterns = [
            r"([A-Z][A-Za-z0-9\-\s]+(?:Pharma|Pharmaceuticals|Biotech|Therapeutics|Inc\.?|LLC|Ltd\.?|GmbH|AG|Corporation|Corp\.?|Laboratories|Labs))",
            r"([A-Z][A-Za-z0-9\-\s]+)(?:,\s+Inc\.?|,\s+LLC|,\s+Ltd\.?|,\s+GmbH|,\s+AG|,\s+Corporation|,\s+Corp\.?)",
        ]

        for pattern in patterns:
            match = re.search(pattern, affiliation)
            if match:
                return match.group(1).strip()

        # If no match found with patterns, try to extract based on commas
        parts = [p.strip() for p in affiliation.split(",")]
        for part in parts:
            if any(
                keyword in part.lower()
                for keyword in ["inc", "llc", "ltd", "gmbh", "ag", "corp"]
            ):
                return part

        return ""
