"""Module for handling output of PubMed search results."""

import csv
import logging
import sys
from typing import Dict, List, Optional, TextIO

import pandas as pd

# Configure logging
logger = logging.getLogger(__name__)


class OutputHandler:
    """Handler for outputting PubMed search results."""

    def __init__(self, debug: bool = False) -> None:
        """
        Initialize the output handler.

        Args:
            debug: Whether to print debug information
        """
        self.debug = debug

    def output_results(
        self, articles: List[Dict], output_file: Optional[str] = None
    ) -> None:
        """
        Output the results to a CSV file or stdout.

        Args:
            articles: List of article dictionaries
            output_file: Path to output file, or None for stdout
        """
        if not articles:
            logger.warning("No articles to output")
            return

        # Prepare data for CSV
        data = []
        for article in articles:
            row = {
                "PubmedID": article.get("pmid", ""),
                "Title": article.get("title", ""),
                "PublicationDate": article.get("publication_date", ""),
                "Non-academicAuthor(s)": "; ".join(
                    article.get("non_academic_authors", [])
                ),
                "CompanyAffiliation(s)": "; ".join(
                    article.get("company_affiliations", [])
                ),
                "CorrespondingAuthorEmail": article.get("corresponding_email", ""),
            }
            data.append(row)

        # Output to file or stdout
        if output_file:
            self._write_to_file(data, output_file)
        else:
            self._write_to_stdout(data)

    def _write_to_file(self, data: List[Dict], output_file: str) -> None:
        """
        Write data to a CSV file.

        Args:
            data: List of dictionaries to write
            output_file: Path to output file
        """
        try:
            df = pd.DataFrame(data)
            df.to_csv(output_file, index=False)
            logger.info(f"Results written to {output_file}")

            if self.debug:
                print(f"Wrote {len(data)} articles to {output_file}")
        except Exception as e:
            logger.error(f"Error writing to file {output_file}: {e}")
            raise

    def _write_to_stdout(self, data: List[Dict]) -> None:
        """
        Write data to stdout.

        Args:
            data: List of dictionaries to write
        """
        try:
            # Create a CSV writer for stdout
            writer = csv.DictWriter(sys.stdout, fieldnames=data[0].keys())
            writer.writeheader()
            writer.writerows(data)

            if self.debug:
                print(f"\nWrote {len(data)} articles to stdout", file=sys.stderr)
        except Exception as e:
            logger.error(f"Error writing to stdout: {e}")
            raise
